
[A,n]=M3D(4);

l=Choleskyf(A);

figure(1)
spy(l)
figure(2)
spy(A)